<?php $__env->startSection('title'); ?>
    <title>Book Bus Tickets For Your Next Trip</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('user.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- START: PAGE TITLE -->
	<div class="row page-title">
		<div class="container clear-padding text-center flight-title">
			<h3>Frequently Asked Questions</h3>
		</div>
	</div>
	<!-- END: PAGE TITLE -->
	
	<!-- START: LOGIN/REGISTER -->
	<div class="row misc-row" style="background-color: white">
		<div class="container clear-padding">
			<div class="col-md-12 clear-padding">
				<h3 class="text-center">Frequently Asked Questions</h3>
				<div class="space"></div>
				<?php if(sizeOf($faqs)>0): ?>
				<div class="panel-group element-accordian" id="accordion">
					<?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne"><?php echo e($faq->question); ?><i class="fa fa-chevron-down pull-right"></i></a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in">
							<div class="panel-body">
								<p><?php echo e($faq->answer); ?></p>
							</div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</div>
				<?php else: ?>
				<p>SORRY! <br/>Questions not added yet, Please check again later.</p>
				<?php endif; ?>
			</div>
			
			
		</div>
	</div>
	<!-- END: LOGIN/REGISTER -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('...layouts.user_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>