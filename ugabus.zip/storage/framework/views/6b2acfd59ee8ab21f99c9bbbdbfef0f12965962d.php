<p> <a href="<?php echo e(route('verify',['token' => $user->email_verification_code])); ?>">
Click here</a> to activate your account</p>