<?php $__env->startSection('title'); ?>
    <title>Book Bus Tickets For Your Next Trip</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('user.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- START: USER PROFILE -->
<div class="row user-profile">
		<div class="container">
			<div class="col-md-12 user-name">
				<h3>Welcome, <?php echo e($user->last_name); ?></h3>
			</div>
			<div class="col-md-2 col-sm-2">
				<div class="user-profile-tabs">
					<ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" 
						href="#profile-overview" class="text-center">
						<i class="fa fa-bolt"></i> <span>Overview</span></a></li>
						<li><a data-toggle="tab" href="#booking" 
						class="text-center"><i class="fa fa-history"></i> 
						<span>Bookings</span></a></li>	
						<li><a data-toggle="tab" href="#profile" 
						class="text-center"><i class="fa fa-user"></i> 
						<span>Profile</span></a></li>
						<li><a data-toggle="tab" href="#cards" 
						class="text-center"><i class="fa fa-credit-card"></i> 
						<span>My Wallet</span></a></li>	
						<li><a data-toggle="tab" href="#wishlist" 
						class="text-center"><i class="fa fa-book"></i> 
						<span>Travel Stories</span></a></li>						
					</ul>
				</div>
			</div>
			<div class="col-md-10 col-sm-10">
				<div class="tab-content">
					<div id="profile-overview" class="tab-pane fade in active">
						<div class="col-md-6">
							<div class="brief-info">
								<div class="col-md-2 col-sm-2 clear-padding">
									<img src="assets/images/user1.jpg" alt="cruise">
								</div>
								<div class="col-md-10 col-sm-10">
									<h3><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h3>
									<h5><i class="fa fa-envelope-o"></i>
									<?php echo e($user->email); ?></h5>
									<h5><i class="fa fa-phone"></i><?php echo e($user->phone); ?></h5>
									<h5><i class="fa fa-map-marker"></i>Burbank, USA</h5>
								</div>
								<div class="clearfix"></div>
								<div class="brief-info-footer">
									<a data-toggle="tab" href="#profile"><i class="fa fa-edit"></i>Edit Profile</a>
									<a href="<?php echo e(route('route.listing')); ?>"><i class="fa fa-plus"></i>Book a bus</a>
								</div>
							</div>
							<div class="clearfix"></div>
							<div class="most-recent-booking">
								<h4>Recent Travels</h4>
								<?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="field-entry">
									<div class="col-md-6 col-sm-4 col-xs-4 clear-padding">
										<p><i class="fa fa-bus"></i><?php echo e($booking->route->travel_from); ?><i class="fa fa-long-arrow-right"></i><?php echo e($booking->route->travel_to); ?></p>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-6">
										<p class="confirmed"><i class="fa fa-check"></i>Confirmed</p>
									</div>
									<div class="col-md-2 col-sm-2 col-xs-2 text-center clear-padding">
										<a href="#">Detail</a>
									</div>
								</div>
								<div class="clearfix"></div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						<div class="col-md-6">
							<!--<div class="user-notification">
									<h4>Notification</h4>
									<div class="notification-body">
										<div class="notification-entry">
											<p><i class="fa fa-plane"></i> Domestic Flights Starting from $199 <span class="pull-right">1m ago</span></p>
										</div>
										<div class="notification-entry">
											<p><i class="fa fa-bed"></i> 20% Cashback on hotel booking <span class="pull-right">1h ago</span></p>
										</div>
										<div class="notification-entry">
											<p><i class="fa fa-bolt"></i> 50% off on all items <span class="pull-right">08h ago</span></p>
										</div>
										<div class="notification-entry">
											<p><i class="fa fa-sun-o"></i> New Year special offer <span class="pull-right">1d ago</span></p>
										</div>
										<div class="notification-entry">
											<p><i class="fa fa-plane"></i> Domestic Flights Starting from $199 <span class="pull-right">1m ago</span></p>
										</div>
										<div class="notification-entry">
											<p><i class="fa fa-bed"></i> 20% Cashback on hotel booking <span class="pull-right">1h ago</span></p>
										</div>
									</div>
							</div>-->
							<div class="user-profile-offer">
								<h4>Offers For You</h4>
								<div class="offer-body">
									<div class="offer-entry">
										<div class="col-md-4 col-sm-4 col-xs-4 offer-left text-center">	
											<p>20% OFF</p>
										</div>
										<div class="col-md-8 col-sm-8 col-xs-8 offer-right">
											<p>Get 20% OFF on flights when you pay with your Bank of America Credit Card. <a href="#">Book Now</a></p>
										</div>
									</div>
									<div class="clearfix"></div>
									<div class="offer-entry">
										<div class="col-md-4 col-sm-4 col-xs-4 offer-left text-center">	
											<p>30% OFF</p>
										</div>
										<div class="col-md-8 col-sm-8 col-xs-8 offer-right">
											<p>Get 30% OFF on flights when you pay with your Bank of America Credit Card. <a href="#">Book Now</a></p>
										</div>
									</div>
									<div class="clearfix"></div>
									<div class="offer-entry">
										<div class="col-md-4 col-sm-4 col-xs-4 offer-left text-center">	
											<p>10% OFF</p>
										</div>
										<div class="col-md-8 col-sm-8 col-xs-8 offer-right">
											<p>Get 10% OFF on flights when you pay with your Bank of America Credit Card. <a href="#">Book Now</a></p>
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>

						</div>
					</div>
					<div id="booking" class="tab-pane fade in">
						<div class="col-md-3 col-sm-3 col-xs-6">
							<form>
								<select class="form-control">
									<option>All Bookings</option>
									<option>Hotel</option>
									<option>Flight</option>
									<option>Holiday</option>
									<option>Cruise</option>
								</select>
							</form>
						</div>
						<div class="clearfix"></div>
						<div class="col-md-12">
							<?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item-entry">
								<span>Order ID: CR1234</span>
								<div class="item-content">
									<div class="item-body">
										<div class="col-md-2 col-sm-2 clear-padding text-center">
											<img src="assets/images/offer1.jpg" alt="cruise">
										</div>
										<div class="col-md-4 col-sm-4">
											<h4><?php echo e($booking->route->bus->agent['company']); ?> 
											<i class="tour-price-single animated growIn slower"
	                                              style="color: #FDC600; font-size: 15px">
	                                                <?php for($k=1; $k <= 5 ; $k++): ?>
	                                                <i data-title="Average Rate: 5 / 5"
	                                                      class="bottom-ratings tip">
	                                                        <i class="glyphicon glyphicon-star<?php echo e(($k <= $booking->route->rating) ? '' : '-empty'); ?>"
	                                                              style="font-size: 15px"></i>
	                                                    </i>
	                                            <?php endfor; ?>
	                                            (<?php echo e($booking->route->rating); ?>)
	                                        </i>
											</h4>
											<p>Leaving from: <?php echo e($booking->route->travel_from); ?> </p>
											<p>Going to: <?php echo e($booking->route->travel_to); ?></p>
										</div>
										<div class="col-md-3 col-sm-3">
											<p class="confirmed"><i class="fa fa-check"></i>Confirmed</p>
										</div>
										<div class="col-md-3 col-sm-3">
											<p><a href="#">Details</a></p>
											<p><a data-toggle="modal" data-target="#myModal<?php echo e($booking->id); ?>" class="btn-info">Review <i class="fa fa-reply"></i></a></p>
										</div>
									</div>
									<div class="item-footer">
										<p><strong>Travel Date:</strong> <?php echo e($booking->created_at); ?><strong>Order Total:</strong> UGx <?php echo e(number_format($booking->route->unit_seat_price)); ?></p>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
							<!-- Modal -->
							<div class="modal fade" id="myModal<?php echo e($booking->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
							  <div class="modal-dialog" role="document">
							    <div class="modal-content">
							      <div class="modal-header">
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
							        <h4 class="modal-title" id="myModalLabel">Review Your Journey</h4>
							      </div>
							      <div class="modal-body">
							     	<form method="post" action="<?php echo e(route('review.submit')); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">

                                            <div class="row" style="padding-left:15px;">
                                                <div class="col-sm-8 col-xs-10">
                                                    <div class="range-advanced-main">
                                                        <div class="range-text">
                                                            <label><span class="range-title">Rate:</span></label>
                                                            <?php echo e(Form::hidden('rating', null, array('id'=>'ratings-hidden'))); ?>

                                                            <div class="text-left">
                                                                <div class="stars starrr"></div>
                                                                <a href="#" class="btn btn-danger btn-sm" id="close-review-box"
                                                                   style="display:none; margin-right:10px;">
                                                                    <span class="glyphicon glyphicon-remove"></span>Cancel</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-8 col-xs-10">
                                                    <div class="form-group">
                                                        <label><span class="range-title">Review:</span></label>
                                                        <textarea class="form-control" name="review" rows="5"
                                                                  placeholder="Your review"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                &nbsp;&nbsp;&nbsp;
                                                <button type="submit" class="btn-round">submit review</button>
                                            </div>
                                        </form>
							      </div>
							      <div class="modal-footer">
							        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							        <button type="button" class="btn btn-primary">Save changes</button>
							      </div>
							    </div>
							  </div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
					<div id="profile" class="tab-pane fade in">
						<div class="col-md-6">
							<div class="user-personal-info">
								<h4>Personal Information</h4>
								<div class="user-info-body">
									<form method="post" action="<?php echo e(route('profile.update')); ?>">
										<?php echo e(csrf_field()); ?>

										<div class="col-md-6 col-sm-6">
											<label>First Name</label>
											<input type="text" name="fname" value="<?php echo e(Auth::guard('user')->user()->first_name); ?>" class="form-control">
										</div>
										<div class="col-md-6 col-sm-6">
											<label>First Name</label>
											<input type="text" name="lname" value="<?php echo e(Auth::guard('user')->user()->last_name); ?>" class="form-control">
										</div>
										<div class="clearfix"></div>
										<div class="col-md-12">
											<label>Email-ID</label>
											<input type="email" name="email" value="<?php echo e(Auth::guard('user')->user()->email); ?>" class="form-control">
										</div>
										<div class="col-md-12">
											<label>Contact Number</label>
											<input type="text" name="contact" value="<?php echo e(Auth::guard('user')->user()->phone); ?>" class="form-control">
										</div>	
										<div class="col-md-12">
											<label>Upload Avatar</label>
											<input type="file" name="profile" class="upload-pic">
										</div>
										<div class="clearfix"></div>
										<div class="col-md-6 col-sm-6 col-xs-6 text-center">
											 <button type="submit">SAVE CHANGES</button>
										</div>
										<div class="col-md-6 col-sm-6 col-xs-6 text-center">
											<a href="#">CANCEL</a>
										</div>
									</form>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="user-change-password">
								<h4>Change Password</h4>
								<div class="change-password-body">
									<form method="post" action="<?php echo e(route('password.reset')); ?>">
										<?php echo e(csrf_field()); ?>

										<div class="col-md-12">
											<label>Old Password</label>
											<input type="password" placeholder="Old Password" class="form-control" name="oldpass">
										</div>
										<div class="col-md-12">
											<label>New Password</label>
											<input type="password" placeholder="New Password" class="form-control" name="newpass">
										</div>
										<div class="col-md-12">
											<label>Confirm Password</label>
											<input type="password" placeholder="Confirm Password" class="form-control" name="confirmpass">
										</div>
										<div class="col-md-12 text-center">
											 <button type="submit">SAVE CHANGES</button>
										</div>
									</form>
								</div>
							</div>
							<!---<div class="user-preference">
								<h4 data-toggle="collapse" data-target="#flight-preference" aria-expanded="false" aria-controls="flight-preference">
										<i class="fa fa-plane"></i> Flight Preference <span class="pull-right"><i class="fa fa-chevron-down"></i></span>
								</h4>
								<div class="collapse" id="flight-preference">
									<form >
										<div class="col-md-6 col-sm-6">
											<label>Price Range</label>
											<select class="form-control" name="flight-price-range">
												<option>Upto $199</option>
												<option>Upto $250</option>
												<option>Upto $499</option>
												<option>Upto $599</option>
												<option>Upto $1000</option>
											</select>
										</div>
										<div class="col-md-6 col-sm-6">
											<label>Food Preference</label>
											<select class="form-control" name="flight-food">
												<option>Indian</option>
												<option>Chineese</option>
												<option>Sea Food</option>
											</select>
										</div>
										<div class="col-md-6 col-sm-6">
											<label>Airline</label>
											<select class="form-control" name="flight-airline">
												<option>Indigo</option>
												<option>Vistara</option>
												<option>Spicejet</option>
											</select>
										</div>
										<div class="clearfix"></div>
										<div class="col-md-12 text-center">
											 <button type="submit">SAVE CHANGES</button>
										</div>
									</form>
								</div>
							</div>-->
							<!---<div class="user-preference">
								<h4 data-toggle="collapse" data-target="#hotel-preference" aria-expanded="false" aria-controls="hotel-preference">
										<i class="fa fa-bed"></i> Hotel Preference <span class="pull-right"><i class="fa fa-chevron-down"></i></span>
								</h4>
								<div class="collapse" id="hotel-preference">
									<form >
										<div class="col-md-6 col-sm-6">
											<label>Price Range</label>
											<select class="form-control" name="hotel-price-range">
												<option>Upto $199</option>
												<option>Upto $250</option>
												<option>Upto $499</option>
												<option>Upto $599</option>
												<option>Upto $1000</option>
											</select>
										</div>
										<div class="col-md-6 col-sm-6">
											<label>Food Preference</label>
											<select class="form-control" name="hotel-food">
												<option>Indian</option>
												<option>Chineese</option>
												<option>Sea Food</option>
											</select>
										</div>
										<div class="col-md-6 col-sm-6">
											<label>Facilities</label>
											<select class="form-control" name="hotel-facilities">
												<option>WiFi</option>
												<option>Bar</option>
												<option>Restaurant</option>
											</select>
										</div>
										<div class="col-md-6 col-sm-6">
											<label>Rating</label>
											<select class="form-control" name="hotel-facilities">
												<option>5</option>
												<option>4</option>
												<option>3</option>
											</select>
										</div>
										<div class="clearfix"></div>
										<div class="col-md-12 text-center">
											 <button type="submit">SAVE CHANGES</button>
										</div>
									</form>
								</div>
							</div>-->
						</div>
					</div>
					<div id="wishlist" class="tab-pane fade in">
						<div class="col-md-12">
						<?php if(sizeOf($stories)>0): ?>
							<?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="item-entry">
									<span><i class="fa fa-clock-o"></i> <?php echo e($story->created_at->diffForHumans()); ?></span>
									<div class="item-content">
										<div class="item-body">
											<div class="col-md-2 col-sm-2 clear-padding text-center">
												<img src="/images/story/admin_listing_150x150/<?php echo e($story->image); ?>" alt="cruise">
											</div>
											<div class="col-md-7 col-sm-7">
												<h4><?php echo e($story->title); ?> <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></h4>
												<p><?php echo str_limit($story->body, $limit = 120, $end = '[...]'); ?></p>
											</div>
											<div class="col-md-3 col-sm-3">
												<p><a href="#">Remove</a></p>
											</div>
										</div>
										<div class="item-footer">
											<div>
												<pclass="pull-left"><strong>Views: </strong> <?php echo e($story->views); ?></p>
												<p class="pull-right"><strong>Share:</strong>
												<a href="#"><i class="fa fa-facebook"></i></a>
												<a href="#"><i class="fa fa-twitter"></i></a>
												<a href="#"><i class="fa fa-instagram"></i></a>
												<a href="#"><i class="fa fa-google-plus"></i></a>
												<a href="#"><i class="fa fa-youtube"></i></a></p>
											</div>
										</div>
										<div class="clearfix"></div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<div class="bottom-pagination">
								<nav class="pull-right">
									<ul class="pagination pagination-lg">
										<?php echo $stories->render(); ?>
									</ul>
								</nav>
							</div>
						<?php else: ?>
							<div class="item-content text-center">
								<p><strong>Sorry no stories in your account yet!</strong></p>
								<a href="#" data-toggle="modal" data-target="#storyModal">
								<span ><i class="fa fa-plus"></i> Add Your Travel Story</span></a>
							</div>
							<!-- Modal -->
							<div class="modal fade" id="storyModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
							  <div class="modal-dialog modal-lg" role="document">
							    <div class="modal-content">
							      <div class="modal-header">
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
							        <h4 class="modal-title" id="myModalLabel">Review Your Journey</h4>
							      </div>
							      <div class="modal-body">
							     	<form class="form form-horizontal" role="form" action="<?php echo e(route('create.story.submit')); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="row" style="padding:15px;">
                                                <h4 class="form-section"><i class="fa fa-rss-square"></i> Blog Post Info</h4>
                                                <div class="form-group row">
                                                    <label class="col-md-2 label-control" for="projectinput1">Title</label>
                                                    <div class="col-md-10">
                                                        <input type="text" id="projectinput1" class="form-control"
                                                               placeholder="Blog Title" name="title">
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                                <div class="form-group row">
                                                    <label class="col-md-2 label-control">Select File</label>
                                                    <div class="col-md-10">
                                                        <label id="projectinput8" class="file center-block">
                                                            <input type="file" id="file" name="photo">
                                                            <span class="file-custom"></span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                                <div class="form-group row">
                                                    <label class="col-md-2 label-control" for="projectinput4">Story</label>
                                                    <div class="col-md-10">
                                                        <textarea class="textarea_editor form-control" rows="15" name="blog-editor"
                                                                  placeholder="Enter text ..."></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="form-group row text-center">
                                                &nbsp;&nbsp;&nbsp;
                                                <button type="submit" class="btn btn-primary">submit Story</button>
                                            </div>
                                        </form>
							      </div>
							      <div class="modal-footer">
							        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
							      </div>
							    </div>
							  </div>
							</div>	
						<?php endif; ?>					
						</div>
					</div>
					<div id="cards" class="tab-pane fade in">
						<div class="col-md-12">
							<div class="col-md-6">
								<div class="card-entry">
									<div class="pull-right">
										<p><a href="#"><i class="fa fa-pencil"></i></a><a href="#"><i class="fa fa-times"></i></a></p>
									</div>
									<h3>XXXX XXXX XXXX 1234</h3>
									<p>Valid Thru 06/17</p>
									<div class="clearfix"></div>
									<div class="card-type">
										<p>Name On Card</p>
										<div class="pull-left">
											<h3>Lenore</h3>
										</div>
										<div class="pull-right">
											<img src="assets/images/card/mastercard.png" alt="cruise">
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="card-entry">
									<div class="pull-right">
										<p><a href="#"><i class="fa fa-pencil"></i></a><a href="#"><i class="fa fa-times"></i></a></p>
									</div>
									<h3>XXXX XXXX XXXX 2345</h3>
									<p>Valid Thru 06/17</p>
									<div class="clearfix"></div>
									<div class="card-type">
										<p>Name On Card</p>
										<div class="pull-left">
											<h3>Lenore</h3>
										</div>
										<div class="pull-right">
											<img src="assets/images/card/visa.png" alt="cruise">
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix"></div>
							<div class="col-md-6">
								<div class="card-entry primary-card">
									<div class="pull-left">
										<span>Primary</span>
									</div>
									<div class="pull-right">
										<p><a href="#"><i class="fa fa-pencil"></i></a><a href="#"><i class="fa fa-times"></i></a></p>
									</div>
									<div class="clearfix"></div>
									<h3>XXXX XXXX XXXX 1234</h3>
									<p>Valid Thru 06/17</p>
									<div class="clearfix"></div>
									<div class="card-type">
										<p>Name On Card</p>
										<div class="pull-left">
											<h3>Lenore</h3>
										</div>
										<div class="pull-right">
											<img src="assets/images/card/mastercard.png" alt="cruise">
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="user-add-card">
									<form >
										<input class="form-control" name="card-number" type="text" required placeholder="Card Number">
										<input class="form-control" name="cardholder-name" type="text" required placeholder="Cardholder Name">
										<div class="col-md-6 col-sm-6 col-xs-6 clear-padding">
											<input class="form-control" name="valid-month" type="text" required placeholder="Expiry Month">
										</div>
										<div class="col-md-6 col-sm-6 col-xs-6">
											<input class="form-control" name="valid-year" type="text" required placeholder="Expiry Year">
										</div>
										<div class="clearfix"></div>
										<div class="col-md-4 clear-padding">
											<input class="form-control" name="cvv" type="password" required placeholder="CVV">
										</div>
										<div class="clearfix"></div>
										<div>
											 <button type="submit">ADD CARD</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					<div id="complaint" class="tab-pane fade in">
						<div class="col-md-12">
							<div class="recent-complaint">
								<h3>Service Requests</h3>
								<div class="complaint-tabs">
									<ul class="nav nav-tabs">
										<li class="active"><a data-toggle="tab" href="#active-complaint" class="text-center"><i class="fa fa-bolt"></i> Active (<?php echo e($complaints->count()-$replied); ?>)</a></li>
										<li><a data-toggle="tab" href="#resolved-complaint" class="text-center"><i class="fa fa-history"></i> Resolved (<?php echo e($replied); ?>)</a></li>	
									</ul>
								</div>
								<div class="tab-content">
									<div id="active-complaint" class="tab-pane fade in active">					
										<?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<p><a href="#"><span>Ticket #123456:</span> <?php echo e($complaint->complaint); ?></a></p>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
									<div id="resolved-complaint" class="tab-pane fade in">
										<?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($complaint->status == 1): ?>
												<p><a href="#"><span>Ticket #123456:</span> <?php echo e($complaint->complaint); ?></a></p>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
								<h3>New Requests</h3>
								<div class="submit-complaint">
									<form >
										<div class="col-md-6 col-sm-6 col-xs-6">
											<label>Category</label>
											<select class="form-control" name="category">
												<option>Flight</option>
												<option>Hotel</option>
												<option>Cruise</option>
												<option>Holiday</option>
											</select>
										</div>
										<div class="col-md-6 col-sm-6 col-xs-6">
											<label>Sub Category</label>
											<select class="form-control" name="sub-category">
												<option>Flight</option>
												<option>Hotel</option>
												<option>Cruise</option>
												<option>Holiday</option>
											</select>
										</div>
										<div class="col-md-12">
											<label>Booking ID</label>
											<input type="text" class="form-control" name="booking-id" placeholder="e.g. CR12567">
										</div>
										<div class="col-md-12">
											<label>Subject</label>
											<input type="text" class="form-control" name="subject" placeholder="Problem Subject">
										</div>
										<div class="col-md-12">
											<label>Problem Description</label>
											<textarea class="form-control" rows="5" name="problem" placeholder="Your Issue"></textarea>
										</div>
										<div class="col-md-12 text-center">
											 <button type="submit">SUBMIT REQUEST</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- END: USER PROFILE -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('...layouts.user_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>