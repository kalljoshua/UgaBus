<?php $__env->startSection('title'); ?>
    <title>Book Bus Tickets For Your Next Trip</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('user.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- START: PAGE TITLE -->
	<div class="row page-title">
		<div class="container clear-padding text-center flight-title">
			<h3>Terms of Use</h3>
		</div>
	</div>
	<!-- END: PAGE TITLE -->
	
	<!-- START: LOGIN/REGISTER -->
	<div class="row misc-row" style="background-color: white">
		<div class="container clear-padding">
			<div class="col-md-12 clear-padding">
				<h3 class="text-center">Terms of Use</h3>
				<div class="space"></div>
				<div class="panel-group element-accordian" id="accordion">
					<div class="common-content">
            <p><strong>SORRY!</strong> <br/>Content will be added soon. Check with us later.</p>
            <p>Contact adminstrators on +256-704741443 for more help.</p>
          </div>
					
				</div>
				
			</div>
			
			
		</div>
	</div>
	<!-- END: LOGIN/REGISTER -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('...layouts.user_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>